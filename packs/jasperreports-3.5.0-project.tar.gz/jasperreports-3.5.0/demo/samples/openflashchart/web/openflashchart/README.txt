- swfobject.js

  SWFObject v2.1: Flash Player detection and embed - http://code.google.com/p/swfobject/
  *
  * (c) 2007-2008 Geoff Stearns, Michael Williams, and Bobby van der Sluis and is released under the MIT License:
  * http://www.opensource.org/licenses/mit-license.php
  
- open-flash-chart.swf

  Open Flash Chart V2 - http://teethgrinder.co.uk/open-flash-chart-2/
  *
  * (C) 2007 John Glazebrook and is released under the LGPL License:
  * http://www.gnu.org/copyleft/lesser.html
