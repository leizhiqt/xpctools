
The XLS exporter that uses the JExcelApi can be tested by launching the 
"ant jxl" target in the following samples:

barbecue
batchexport
crosstabs
csvdatasource
datasource
fonts
hibernate
horizontal
hyperlink
i18n
images
jasper
java1.5
jcharts
jfreechart
landscape
nopagebreak
noreport
noxmldesign
query
rotation
scriptlet
shapes
stretch
styledtext
subreport
table
tableofcontents
unicode
xmldatasource
